Team Codebreakers
=================

Lingliang Zhang (lz781@nyu.edu)
Abhinav Tamaskar (abt237@nyu.edu)

To Compile

g++ darwin.cpp -o darwinSolver

To Run

./start.sh A input.file output.file
